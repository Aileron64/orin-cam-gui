import os
#os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
#os.environ['CUDA_VISIBLE_DEVICES'] = '1'
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
#import tkinter 
import cv2
import keras
import numpy as np
#import matplotlib
#matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

from icecream import ic

#from utils import slice_image,stitch_tensor
import segmentation_models as sm





preprocess_input = None

def remove_background(img):
    i = img.copy()
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, (0, 100, 70), (50, 185,255))
    mask = cv2.morphologyEx(mask,cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT,(13,13)),iterations=3)
    new1 = cv2.bitwise_and(i,i,mask=mask)
    imgray = cv2.cvtColor(new1, cv2.COLOR_RGB2GRAY)
    blur = cv2.GaussianBlur(imgray,(5,5),5)
    edges = cv2.Canny(image=imgray, threshold1=0, threshold2=255)
    
    height,width,_ = np.shape(img)
    blank_image = np.zeros((height,width), np.uint8)    
    contours, hierarchy = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    for p,cnt in enumerate(contours):
                rect = cv2.minAreaRect(cnt)
                w,h = rect[1]
                area = w*h
                if area > 1000:
                    box = cv2.boxPoints(rect)
                    box = np.int0(box)
                    cv2.drawContours(blank_image,[box],0,(255,255,255),-1)  
                    cv2.drawContours(new1,[box],-1,(255,255,255),1)  

    

    mask_new = cv2.bitwise_or(mask,blank_image)



    new1 = cv2.bitwise_and(i,i,mask=mask_new)
    hsv1 = cv2.bitwise_and(hsv,hsv,mask=mask_new)
    mask_new1 = cv2.inRange(hsv, (100, 0, 70), (255, 255,255))
    mask_new1 = cv2.morphologyEx(mask_new1,cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT,(3,3)),iterations=2)

    mask_new2 = cv2.inRange(hsv, (100, 0, 0), (255, 255,185))
    #mask_new2 = cv2.inRange(hsv, (100, 0, 0), (255, 155,185))
    mask_new2 = cv2.morphologyEx(mask_new2,cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT,(3,3)),iterations=4)

    mask_new3 = cv2.inRange(hsv, (254, 254, 254), (255,255 ,255))
    mask_new3 = cv2.morphologyEx(mask_new3,cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT,(3,3)),iterations=2)
    #mask_new = cv2.bitwise_not(mask_new,mask_new1)



    new1 = cv2.bitwise_and(i,i,mask=mask_new)
    new1[mask_new1==255] = 0
    new1[mask_new2==255] = 0
    #new1[mask_new3==255] = 0

    mask_new4 = cv2.inRange(new1, (252, 252, 252), (255,255 ,255))

    mask_new4 = cv2.morphologyEx(mask_new4,cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3)),iterations=1)
    new1[mask_new4==255] = 0
    return new1






def process_count(fname,image):
        output = image.copy()
        mask = cv2.inRange(image, (190, 190, 190), (255, 255,255))
        image[mask!=255]=0
        gray = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
        th3 = cv2.adaptiveThreshold(gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,3,3)
        edges = cv2.Canny(image=th3, threshold1=0, threshold2=255)
        edges = cv2.morphologyEx(edges,cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3)),iterations=1)

        height,width,_ = np.shape(image)
        blank_image = np.zeros((height,width), np.uint8)    
        #contours, hierarchy = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        cnt_seeds = 0

        (totalLabels, label_ids, values, centroid) = cv2.connectedComponentsWithStats(edges, 4 , cv2.CV_32S)
        """
        for p,cnt in enumerate(contours):
                    rect = cv2.minAreaRect(cnt)
                    w,h = rect[1]
                    area = w*h
                    #if  1000 >area > 30:
                    if area > 30 and area < 2000:
                        box = cv2.boxPoints(rect)
                        box = np.int0(box)
                        #cv2.drawContours(blank_image,[box],0,(255,255,255),-1)  
                        cv2.drawContours(blank_image,[cnt],0,(255,255,255),-1)  
                        #cv2.drawContours(image,[box],-1,(255,255,255),1)  
                        #cv2.drawContours(image,[cnt],-1,(255,255,255),5)  
                        #cv2.drawContours(image,[cnt],-1,(255,255,255),5)  
                        #cv2.drawContours(output,[box],-1,(0,0,255),3)  
                        #cv2.drawContours(output,[cnt],0,(255,255,255),-1)  
                        M = cv2.moments(cnt)
                        cX = int(M["m10"] / M["m00"])
                        cY = int(M["m01"] / M["m00"])
                       # cv2.drawContours(output,[cnt],1,(0,0,255),-1)  
                        cv2.circle(output, (int(cX),
                                        int(cY)),
                            1, (0, 0, 255), -1)
                        cnt_seeds+=1
        """

        """
        cnt_trays=0

        for p,cnt in enumerate(contours):
            rect = cv2.minAreaRect(cnt)
            w,h = rect[1]
            area = int(w*h)
            
            if area>int(0.3*height*width) and area<int(0.6*height*width):
                        box = cv2.boxPoints(rect)
                        box = np.int0(box)

            ##and int(area < 0.2*height*width):
                        ic (area)
                        #ic(cnt)
                        #ic(box)
                        cv2.drawContours(output,[box],-1,(0,0,255),3)  
                        cnt_trays+=1
            
            
        """
        #"""
        for i in range(1, totalLabels):
            area = values[i, cv2.CC_STAT_AREA] 
        
            if (area > 20) and (area < 3000):
                
                    # Labels stores all the IDs of the components on the each pixel
                    # It has the same dimension as the threshold
                    # So we'll check the component
                    # then convert it to 255 value to mark it white
                    componentMask = (label_ids == i).astype("uint8") * 255
                    x1 = values[i, cv2.CC_STAT_LEFT]
                    y1 = values[i, cv2.CC_STAT_TOP]
                    w = values[i, cv2.CC_STAT_WIDTH]
                    h = values[i, cv2.CC_STAT_HEIGHT]
                    pt1 = (x1, y1)
                    pt2 = (x1+ w, y1+ h)
                    (X, Y) = centroid[i]
                    cv2.circle(output, (int(X),
                                        int(Y)),
                            1, (0, 0, 255), -1)
                    
                    # Creating the Final output mask
                    cnt_seeds+=1
                    blank_image = cv2.bitwise_or(blank_image, componentMask)

        #"""      
        #blank_image=
        from icecream import ic
        ic(cnt_seeds)

        #cv2.imshow("edges",edges)
#        cv2.imshow("Blank",blank_image)
#        cv2.imshow("image222",th3)
#        cv2.imshow("mask",mask)
        #cv2.imshow("image333",image)
#        cv2.imshow("Output",output)
#        cv2.waitKey(0)

        #ic(len(contours))
        fname1 = fname + f"_{str(cnt_seeds)}.jpg"
        cv2.imwrite(fname1,output)

    

# helper function for data visualization
def visualize(**images):
    """PLot images in one row."""
    global filename
    n = len(images)
    plt.figure(figsize=(16, 5))
    #cv2.imshow('sample image',np.asarray(255*images["image"],dtype=np.uint8))
    
    #ic(images)
    
    for i, (name, image) in enumerate(images.items()):
        plt.subplot(1, n, i + 1)
        plt.xticks([])
        plt.yticks([])
        plt.title(' '.join(name.split('_')).title())
        
        #plt.plot(image)
        plt.imshow(image)
        
        #if i==0:
        #    plt.imshow(image, alpha=.6)
        #else:    
        #    plt.imshow(image, alpha=.4)
        
    #plt.savefig('ucsf_output_effnetb3_testvalVerti/'+filename+'.png', bbox_inches='tight')
    plt.savefig(dump_dir+filename+'.png', bbox_inches='tight')
    #plt.show()
    
# helper function for data visualization    
def denormalize(x):
    """Scale image to range 0..1 for correct plot"""
    x_max = np.percentile(x, 98)
    x_min = np.percentile(x, 2)    
    x = (x - x_min) / (x_max - x_min)
    x = x.clip(0, 1)
    return x
    


HGHT=512
WDTH=512

BACKBONE = 'mobilenet'
#BACKBONE = 'resnet50'
#BACKBONE = 'densenet121'
#BACKBONE="efficientnetb4"

BATCH_SIZE = 1
#CLASSES = ["tipburn","healthy","background"]
CLASSES = ["trays"]
LR = 0.0001
#LR = 0.001
EPOCHS = 40

preprocess_input = sm.get_preprocessing(BACKBONE)



# define network parameters
#n_classes = 1 if len(CLASSES) == 1 else (len(CLASSES) + 1)  # case for binary and multiclass segmentation

n_classes=1
activation = 'sigmoid' if n_classes == 1 else 'softmax'

#create model
#model = sm.Unet(BACKBONE, classes=n_classes, activation=activation,input_shape=(512, 512, 3))

model = sm.Unet(BACKBONE, classes=n_classes, activation=activation,input_shape=(512, 512, 3))

optim = keras.optimizers.Adam(LR)

# Segmentation models losses can be combined together by '+' and scaled by integer or float factor
dice_loss = sm.losses.DiceLoss()
focal_loss = sm.losses.BinaryFocalLoss() if n_classes == 1 else sm.losses.CategoricalFocalLoss()
total_loss = dice_loss + (1 * focal_loss)

# actulally total_loss can be imported directly from library, above example just show you how to manipulate with losses
# total_loss = sm.losses.binary_focal_dice_loss # or sm.losses.categorical_focal_dice_loss 

metrics = [sm.metrics.IOUScore(threshold=0.5), sm.metrics.FScore(threshold=0.5)]

# compile keras model with defined optimozer, loss and metrics
model.compile(optim, total_loss, metrics)

#model.load_weights('best_model_effnetb3.h5') 
#model.load_weights('best_model_densenetiou87.h5') 

#model.load_weights("ucsf2_best_model_mobilenet_finetuned.h5")
model.load_weights("cp_best_mobilenet_from_finetuned.h5")


import glob
fnames = glob.glob("testImages/*")
#fnames = glob.glob("testTrain1/*")
dump_dir = "images_out"
#for i,elem in enumerate(fnames[:1]):
for i,elem in enumerate(fnames):
    ic(elem)

    image_big = cv2.imread(elem)
    HGHT_L = np.shape(image_big)[0]
    WDTH_L = np.shape(image_big)[1]
    image_copy = image_big.copy()
    #image_b = image_big.copy()
    #img_back_removed = remove_background(image_big)
    
    image_small = cv2.resize(image_big, (HGHT,WDTH), interpolation = cv2.INTER_AREA) 
    image_small = cv2.cvtColor(image_small, cv2.COLOR_BGR2RGB)
    image_small = np.expand_dims(image_small, axis=0)
        
    pr_mask = model.predict(image_small).round()
    
#    ic(pr_mask)
    #.round()
        
 #   ic(i)
    pr_mask=pr_mask[..., 0].squeeze()
    
    #pr_mask_color_gray = cv2.cvtColor(pr_mask,cv2.COLOR_GRAY2BGR)
    
    
    pr_mask_big_gray = cv2.resize(pr_mask, (WDTH_L,HGHT_L), interpolation = cv2.INTER_AREA) 
    pr_mask_big_color =  cv2.cvtColor(pr_mask_big_gray,cv2.COLOR_GRAY2BGR)
    pr_mask_big_color[pr_mask_big_gray>0] = (0,0,255)
    pr_mask_big_color = np.asarray(pr_mask_big_color, np.uint8)
    
    
    #pr_mask_color_big[]
    #ic(pr_mask_color)
    

    
    #cv2.imshow("img",pr_mask_color)
    #cv2.imshow("img1",image_small)
    
    
    added_image = cv2.addWeighted(image_big,0.6,pr_mask_big_color,0.4,0)
    image_big[pr_mask_big_gray<0.6]=(0,0,0)
    
    #imgCombined = np.hstack((image_big, pr_mask_color,added_image))
    imgCombined = np.hstack((image_copy,image_big, pr_mask_big_color,added_image,image_big))
    #imgCombined = np.hstack((image_small.squeeze(), pr_mask_color))
    #imgCombined = np.hstack((image_small.squeeze(), pr_mask_color))
    fn = os.path.join(dump_dir,str(i)+"_overlay.jpg")
    fn1 = os.path.join(dump_dir,str(i)+"_seeds_counted")

    process_count(fn1,image_big)
    cv2.imwrite(fn,imgCombined)
    
    #cv2.imshow("img_added",added_image)
    
    
    """
    ############################################################################### ADDING BOXXXXXXXXXXX ###############
    imgray = cv2.cvtColor(maskk, cv2.COLOR_RGB2GRAY)
    #blur = cv2.GaussianBlur(imgray,(5,5),5)
    ret, thresh = cv2.threshold(imgray, 0, 255, 0)
    edges = cv2.Canny(image=thresh, threshold1=0, threshold2=255)
    #cv2.imwrite()
    #cv2.imshow("Aaaa",edges)
    cv2.imwrite("aaa.png",thresh)
    #cv2.waitKey(0)
    print("##############################################################")
    height,width,_ = np.shape(img)
    blank_image = np.zeros((height,width), np.uint8)    
    contours, hierarchy = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    ic(len(contours))
    for p,cnt in enumerate(contours):
            rect = cv2.minAreaRect(cnt)
            w,h = rect[1]
            area = w*h
            #if True:
            if area < 1200:
                box = cv2.boxPoints(rect)
                box = np.int0(box)
                #cv2.drawContours(maskk,[box],0,(255,255,255),-1)  
                #cv2.drawContours(maskk,[box],0,(255,255,255),-1)  
                #cv2.drawContours(maskk,[box],0,(0,0,255),-1)  
                cv2.drawContours(maskk,[box],0,(0,255,0),-1)  
                #cv2.drawContours(maskk,[cnt],0,(0,0,255),-1)  
                #cv2.drawContours(new1,[box],-1,(255,255,255),1)  
            elif 6000 >area >=  1280:
                box = cv2.boxPoints(rect)
                box = np.int0(box)

                
                cv2.drawContours(maskk,[box],0,(255,0,0),-1)  
            elif area >= 6000:
                box = cv2.boxPoints(rect)
                box = np.int0(box)

                cv2.drawContours(maskk,[box],0,(0,0,255),-1)  
                

    ############################################################################### ADDING BOXXXXXXXXXXX ###############
    
    
    
    #img_back_removed = remove_background(img)
    maskk[img_back_removed==0]=0
    
    resized_shape = (big_img_shape[1]//5,big_img_shape[0]//5)
    
    pr_mask_resized=cv2.resize(maskk, resized_shape, interpolation = cv2.INTER_AREA)
    img_resized=cv2.resize(img, resized_shape, interpolation = cv2.INTER_AREA)
    #added_image = cv2.addWeighted(pr_mask_resized,0.3,img_resized,0.7,0)
    ic(np.shape(pr_mask_resized))
    ic(np.shape(img_resized))
    ic(np.shape(img))
    ic(np.shape(maskk))
    
    
    
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
    added_image = cv2.addWeighted(img,0.6,maskk,0.4,0)
    
    
    #cv2.imshow("img",pr_mask_resized)
    #cv2.imshow("img1",img_resized)
    #cv2.imshow("img_added",added_image)
    
    #cv2.waitKey(0)
    #cv2.destroyAllWindows()     
    
                
    #cv2.imshow("img",img)
    #cv2.waitKey(0)
    #cv2.destroyAllWindows()     
        
    filename=str(i)    
    
    
    
    
    img_resized= cv2.cvtColor(img_resized, cv2.COLOR_RGB2BGR)
    imgCombined = np.hstack((img_resized, pr_mask_resized))
    #added_image = cv2.cvtColor(added_image, cv2.COLOR_RGB2BGR)
    
    
    
    cv2.imwrite(os.path.join(dump_dir,filename+"_overlay.png"),added_image)
    cv2.imwrite(os.path.join(dump_dir,filename+".png"),imgCombined)
    cv2.imwrite(os.path.join(dump_dir,filename+"_actual.png"),img)
    #np st
    """    
    
    """
    visualize(
            img=denormalize(img.squeeze()),
    #        tiss_mask=gt_mask[..., 0].squeeze(),
            #gr_mask=pr_mask[..., 1].squeeze(),
            #pr_mask=pr_mask0,
            pr_mask=maskk,
    )
    """
